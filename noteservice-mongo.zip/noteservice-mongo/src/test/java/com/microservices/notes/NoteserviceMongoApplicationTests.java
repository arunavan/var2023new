package com.microservices.notes;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NoteserviceMongoApplicationTests {

	@Test
	void contextLoads() {
	}

}
