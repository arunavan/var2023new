package com.examples.post;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PostcrudapplicationApplication {

	public static void main(String[] args) {
		SpringApplication.run(PostcrudapplicationApplication.class, args);
	}

}
