package com.examples.post;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PostcrudapplicationApplicationTests {

	@Test
	void contextLoads() {
	}

}
