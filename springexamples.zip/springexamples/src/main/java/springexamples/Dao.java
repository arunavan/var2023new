package springexamples;

public interface Dao {
	public String getConnection();
}
